function nav(params) {
    document.getElementById('contact').style.display="none"; 
    document.getElementById('portfolio').style.display="none"; 
    document.getElementById('about').style.display="none"; 
    document.getElementById('home').style.display="none"; 
//    document.getElementById(params).style.display="block"; 
   $('#'+params).fadeToggle(3000);
    
}